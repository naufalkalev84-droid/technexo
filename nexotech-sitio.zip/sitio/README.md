# NexoTech — Sitio de tecnología

Sitio estático (HTML/CSS/JS puro, sin frameworks ni build step) listo para subir a
Netlify, Vercel o GitHub Pages.

## Qué incluye

- Home, listado de artículos, 6 páginas de categoría, buscador, sobre nosotros,
  contacto, privacidad, cookies, términos, 404.
- 6 artículos de ejemplo completos (contenido real, no inventado ni copiado),
  uno por categoría, con TOC, breadcrumbs, datos estructurados (Schema.org),
  bloques de afiliados y espacios de anuncios ya maquetados.
- `sitemap.xml`, `robots.txt`, Open Graph, favicon, meta tags por página.
- Modo claro/oscuro, diseño responsive completo.
- Panel `/admin` con Decap CMS pre-configurado.

## ⚠️ Punto importante sobre el panel /admin

El panel Decap CMS ya está configurado en `admin/config.yml`, pero **por ahora
solo va a guardar los artículos como archivos Markdown en `content/articulos/`**;
todavía no están conectados automáticamente al sitio, que hoy lee los artículos
desde `assets/js/data.js`.

Para que el panel funcione de punta a punta (escribís en `/admin` → aparece en
el sitio) hace falta un paso más: o bien (a) un pequeño script de build que
convierta esos Markdown en entradas de `data.js`, o (b) migrar a un generador
como Astro/11ty que lea `content/articulos/` directamente. Si querés, puedo
armar ese script a continuación — es la pieza que falta para que el flujo sea
100% sin tocar código.

Mientras tanto, para agregar un artículo nuevo "a mano": copiá la carpeta de
un artículo existente dentro de `/articulos/`, editá su HTML, y agregá una
entrada nueva en `ARTICLES` dentro de `assets/js/data.js` y en `sitemap.xml`.

## Cómo desplegarlo (gratis)

1. Subí esta carpeta a un repositorio de GitHub.
2. Entrá a [Netlify](https://netlify.com) → "Add new site" → conectá el repo.
   Build command: (vacío). Publish directory: `/` (raíz).
3. Para activar `/admin`: Site settings → Identity → Enable → Services →
   Enable Git Gateway → invitate tu email como usuario.
4. Reemplazá `https://www.nexotech.example` por tu dominio real en todos los
   archivos (`sitemap.xml`, meta tags `og:url`/`canonical` de cada página).

## Antes de activar AdSense

- Los `<div class="ad-slot">` son placeholders — reemplazalos por el código
  de anuncio real de AdSense cuando tengas la cuenta aprobada.
- Revisá que Google Search Console tenga el sitemap enviado.
- El sitio necesita contenido publicado y tráfico orgánico antes de que
  AdSense suela aprobar la cuenta — no lo actives antes de tiempo.

## Pendientes sugeridos

- Conectar el formulario de contacto a un servicio real (Formspree, Netlify
  Forms) — hoy solo simula el envío en el navegador.
- Ampliar la biblioteca de artículos por categoría.
- Configurar Google Analytics o similar (respetando la política de cookies).
