// ============================================================
// NEXOTECH — Fuente de datos de artículos y categorías
// En producción, este archivo puede generarse automáticamente
// a partir de los Markdown que gestiona Decap CMS.
// ============================================================

const CATEGORIES = [
  { slug: "celulares-y-accesorios", name: "Celulares y Accesorios", color: "var(--cat-celulares)" },
  { slug: "pc-y-componentes",       name: "PC y Componentes",       color: "var(--cat-pc)" },
  { slug: "gaming",                 name: "Gaming",                 color: "var(--cat-gaming)" },
  { slug: "inteligencia-artificial",name: "Inteligencia Artificial",color: "var(--cat-ia)" },
  { slug: "reviews-y-comparativas", name: "Reviews y Comparativas", color: "var(--cat-reviews)" },
  { slug: "guias-y-tutoriales",     name: "Guías y Tutoriales",     color: "var(--cat-guias)" },
];

const ARTICLES = [
  {
    slug: "como-elegir-funda-celular",
    title: "Cómo elegir una funda para tu celular sin arruinar el diseño",
    excerpt: "Los materiales, grosores y tipos de protección que existen, y cómo elegir según el uso real que le das a tu equipo.",
    category: "celulares-y-accesorios",
    tags: ["fundas", "accesorios", "proteccion"],
    date: "2026-06-02",
    readingTime: 6,
    url: "/articulos/como-elegir-funda-celular/"
  },
  {
    slug: "ssd-vs-hdd-2026",
    title: "SSD vs HDD: qué disco conviene según el uso que le vas a dar",
    excerpt: "Diferencias reales de velocidad, durabilidad y precio por gigabyte entre ambas tecnologías de almacenamiento.",
    category: "pc-y-componentes",
    tags: ["almacenamiento", "ssd", "hardware"],
    date: "2026-05-20",
    readingTime: 8,
    url: "/articulos/ssd-vs-hdd-2026/"
  },
  {
    slug: "setup-gaming-comodo",
    title: "Cómo armar un setup gaming cómodo sin gastar de más",
    excerpt: "Ergonomía, distancia de pantalla, iluminación y orden de prioridades para armar tu espacio de juego.",
    category: "gaming",
    tags: ["setup", "ergonomia", "escritorio"],
    date: "2026-05-08",
    readingTime: 7,
    url: "/articulos/setup-gaming-comodo/"
  },
  {
    slug: "que-es-un-modelo-de-lenguaje",
    title: "Qué es un modelo de lenguaje (LLM) y cómo funciona, explicado simple",
    excerpt: "Una explicación sin tecnicismos de cómo estos sistemas aprenden a generar texto y qué pueden y no pueden hacer.",
    category: "inteligencia-artificial",
    tags: ["ia", "llm", "conceptos"],
    date: "2026-06-10",
    readingTime: 9,
    url: "/articulos/que-es-un-modelo-de-lenguaje/"
  },
  {
    slug: "guia-compra-auriculares-cancelacion-ruido",
    title: "Auriculares con cancelación de ruido: guía de compra",
    excerpt: "Qué características importan realmente antes de comprar unos auriculares con ANC, más allá de la marca.",
    category: "reviews-y-comparativas",
    tags: ["auriculares", "audio", "guia-de-compra"],
    date: "2026-04-28",
    readingTime: 7,
    url: "/articulos/guia-compra-auriculares-cancelacion-ruido/"
  },
  {
    slug: "cuidar-bateria-notebook",
    title: "Cómo cuidar la batería de tu notebook a largo plazo",
    excerpt: "Hábitos de carga y uso que ayudan a que la batería de tu notebook mantenga su capacidad con el paso del tiempo.",
    category: "guias-y-tutoriales",
    tags: ["bateria", "notebook", "mantenimiento"],
    date: "2026-04-15",
    readingTime: 5,
    url: "/articulos/cuidar-bateria-notebook/"
  }
];

function getCategory(slug) {
  return CATEGORIES.find(c => c.slug === slug);
}

function formatDate(iso) {
  const d = new Date(iso + "T00:00:00");
  return d.toLocaleDateString("es-AR", { day: "2-digit", month: "short", year: "numeric" });
}
