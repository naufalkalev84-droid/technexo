// ============================================================
// NEXOTECH — Render de tarjetas, buscador y utilidades de UI
// ============================================================

function cardHTML(article) {
  const cat = getCategory(article.category);
  return `
    <a class="card" href="${article.url}">
      <div class="card-media" style="background:linear-gradient(135deg, color-mix(in srgb, ${cat.color} 18%, var(--surface)), var(--surface));">
        <span>${cat.name}</span>
      </div>
      <div class="card-body">
        <div class="meta-row">
          <span class="led" style="background:${cat.color}"></span>
          <span>${cat.name}</span>
          <span>·</span>
          <span>${article.readingTime} min</span>
        </div>
        <h3>${article.title}</h3>
        <p class="excerpt">${article.excerpt}</p>
      </div>
    </a>`;
}

function listRowHTML(article) {
  const cat = getCategory(article.category);
  return `
    <a class="card-list-row" href="${article.url}">
      <div class="card-media" style="background:linear-gradient(135deg, color-mix(in srgb, ${cat.color} 18%, var(--surface)), var(--surface));"></div>
      <div class="card-body" style="padding:0;">
        <div class="meta-row">
          <span class="led" style="background:${cat.color}"></span>
          <span>${cat.name}</span>
          <span>·</span>
          <span>${formatDate(article.date)}</span>
          <span>·</span>
          <span>${article.readingTime} min</span>
        </div>
        <h3>${article.title}</h3>
        <p class="excerpt">${article.excerpt}</p>
      </div>
    </a>`;
}

function renderGrid(containerId, articles) {
  const el = document.getElementById(containerId);
  if (!el) return;
  if (!articles.length) {
    el.innerHTML = `<div class="empty-state"><h3>No hay artículos todavía</h3><p>Probá con otra categoría o volvé pronto.</p></div>`;
    return;
  }
  el.innerHTML = articles.map(cardHTML).join("");
}

function renderList(containerId, articles) {
  const el = document.getElementById(containerId);
  if (!el) return;
  if (!articles.length) {
    el.innerHTML = `<div class="empty-state"><h3>No encontramos resultados</h3><p>Probá con otros términos de búsqueda.</p></div>`;
    return;
  }
  el.innerHTML = articles.map(listRowHTML).join("");
}

function sortByDateDesc(list) {
  return [...list].sort((a, b) => new Date(b.date) - new Date(a.date));
}

// ---------- Tema claro/oscuro ----------
function initTheme() {
  const saved = localStorage.getItem("nexotech-theme");
  const preferred = saved || (window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light");
  if (preferred === "dark") document.documentElement.setAttribute("data-theme", "dark");
  const btn = document.getElementById("theme-toggle");
  if (btn) {
    btn.addEventListener("click", () => {
      const isDark = document.documentElement.getAttribute("data-theme") === "dark";
      if (isDark) {
        document.documentElement.removeAttribute("data-theme");
        localStorage.setItem("nexotech-theme", "light");
      } else {
        document.documentElement.setAttribute("data-theme", "dark");
        localStorage.setItem("nexotech-theme", "dark");
      }
    });
  }
}

// ---------- Buscador ----------
function initSearch() {
  const input = document.getElementById("search-input");
  if (!input) return;
  const params = new URLSearchParams(window.location.search);
  const q = params.get("q") || "";
  input.value = q;
  runSearch(q);
  input.addEventListener("input", (e) => runSearch(e.target.value));
}

function runSearch(query) {
  const q = query.trim().toLowerCase();
  const results = !q ? [] : ARTICLES.filter(a =>
    a.title.toLowerCase().includes(q) ||
    a.excerpt.toLowerCase().includes(q) ||
    a.tags.some(t => t.toLowerCase().includes(q)) ||
    getCategory(a.category).name.toLowerCase().includes(q)
  );
  const countEl = document.getElementById("search-count");
  if (countEl) {
    countEl.textContent = q ? `${results.length} resultado(s) para "${query}"` : "Escribí un término para buscar";
  }
  renderList("search-results", sortByDateDesc(results));
}

document.addEventListener("DOMContentLoaded", () => {
  initTheme();
  initSearch();
});
